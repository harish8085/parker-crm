<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/import.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/add.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="import-header d-block">
    <div class="row">
        <div class="col-sm-6">
            <h2 class="upload-file-heading">Upload Bank MIS File</h2>

        </div>
        <div class="col-sm-3">
            <select class="form-select" required id="type">
                <option value="" selected disabled>Select Bank</option>
                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-3">
            <select class="form-select" required id="product_type">
                <option value="" selected>Select Product</option>
            </select>
        </div>
    </div>
</div>

<div>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(url('/upload-mis/create')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="file-container" id="cont">
            <input class="input-file" type="hidden" required name="bank_id" id="bank_id" />
            <input class="input-file" type="hidden" required name="product_id" id="product_id" />
            <input class="input-file" type="file" accept=".xlsx" required name="xlsx_file" id="xlsx_file" />
            <div class="content-container">
                <img src="<?php echo e(asset('assets/images/cloud-upload-img.svg')); ?>" id="img">
                <h4 id="h4">Drag Your Files here <br /> Or</h4>
                <p id="p">Browse</p>
            </div>

        </div>
        <div class="save-btn-container">
            <div class="loader-1">
                <div class="loader-div">
                    <div class="loader"></div>
                </div>
            </div>
            <button class="save-btn" id="submitBtn">Upload</button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#submitBtn').click(function() {
            $('#submitBtn').hide()
            $('.loader-1').show()

        })

        $('#xlsx_file').change(function() {
            if ($(this).val()) {
                $('#cont').addClass('file-container-filled')
                $('#h4').html('Re Upload Your Files here <br /> Or')
                $('#p').html('Remove')
                $('#p').addClass('text-dark')
                $('#img').attr('src', `<?php echo e(asset('assets/images/delete.svg')); ?>`);
            } else {
                $('#cont').removeClass('file-container-filled')
                $('#h4').html('Drag Your Files here <br /> Or')
                $('#p').html('Browse')
                $('#p').removeClass('text-dark')

                $('#img').attr('src', `<?php echo e(asset('assets/images/cloud-upload-img.svg')); ?>`);
            }


        })
        $('#type').change(function() {
            $('#bank_id').val($(this).val())
        })

        $('#product_type').change(function() {
            $('#product_id').val($(this).val())
        })


        $('#type').change(function() {
            if ($('#type').val()) {
                performAjaxRequest('/getAllProduct', 'POST', {
                    bank_id: $('#type').val(),
                }, function(response) {
                    var select = $('#product_type')
                    select.empty().append($('<option>', {
                        value: '',
                        text: 'Select Product',
                        disabled: true,
                        selected: true
                    }));

                    $.each(response, function(key, value) {
                        select.append($('<option>', {
                            value: value.id,
                            text: `${value.name} (${value.group})`
                        }));
                    });
                });
            }

        });

        function performAjaxRequest(url, type, data, successCallback) {
            $.ajax({
                url: url,
                type: type,
                data: data,
                success: successCallback,
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Application/Bank-MIS/index.blade.php ENDPATH**/ ?>