  <table class="table table-hover data-table">
      <thead>
          <tr>
              <th class="table-header">Bank ID</th>
              <th class="table-header">Bank Name</th>
              <th class="table-header">Short Name</th>
              <th class="table-header">Actions</th>
          </tr>
      </thead>
      <tbody>
        
      </tbody>
  </table><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Bank/Table/bank_table.blade.php ENDPATH**/ ?>