<?php

$name = ucfirst(strtolower(Auth::user()->first_name))." ".ucfirst(strtolower(Auth::user()->last_name));
$avatar = Avatar::create($name)->toBase64();

?>
<div class="appbar-container">
    <!-- navbar -->
    <div class="navbar-container">
        <div class="navbar-toggler-container">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" style="color: black;">
                <span class="navbar-toggler-icon"><img src="<?php echo e(asset('assets/images/hamburgur.svg')); ?>"></span>
            </button>
        </div>
        <div>
            <ul class="nav-ul">
                <!-- Admin dropdown -->
                <li class="nav-item dropdown" style="padding: 16px 10px; position: relative;">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img class="admin-icon" src="<?php echo e($avatar); ?>" width="50" alt="Profile Picture">
                        <span class="admin"><?php echo e($name); ?></span>
                        <span class="dropdown-arrow">▼</span>
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: white;">
                    <li><a class="dropdown-item" href="<?php echo e(url('profile')); ?>">Profile Settings</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(url('logout')); ?>">Logout</a></li>
                    </ul>
                </li>
                <!-- Logout button -->
                <!-- <li class="nav-item" style="padding: 16px 40px;">
                    <a class="nav-link" href="<?php echo e(url('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" style="color: black;">
                        Logout
                    </a>
                    <form id="logout-form" action="<?php echo e(url('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li> -->
            </ul>
        </div>
    </div>
</div><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Layout/navbar.blade.php ENDPATH**/ ?>