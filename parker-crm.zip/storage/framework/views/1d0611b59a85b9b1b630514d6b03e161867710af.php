<div class="sidebar-container">
    <div>
        <div class="logo-container">
            <a href="/">

                <img class="logo" src="<?php echo e(asset('assets/images/logo.png')); ?>" width="50px" height="50px">
            </a>
        </div>

        <div>
            <ul class="ul-container">
                <li class="list-item <?php echo e((Request::path() == 'dashboard')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'dashboard')?'active-li':''); ?>" href="<?php echo e(url('dashboard')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'dashboard')?'assets/images/home-active.svg':'assets/images/home.svg')); ?>" alt="error">Dashboard</a>
                </li>
                <?php if(auth()->user()->hasPermission('application','view')): ?>
                <li class="list-item <?php echo e((Request::path() == 'application')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'application')?'active-li':''); ?>" href="<?php echo e(url('application')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'application')?'assets/images/application-active.svg':'assets/images/application.svg')); ?>" alt="error">Application
                    </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('bank_mis','view')): ?>
                <li class="list-item <?php echo e((Request::path() == 'bank_mis')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'bank_mis')?'active-li':''); ?>" href="<?php echo e(url('bank_mis')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'bank_mis')?'assets/images/application-active.svg':'assets/images/application.svg')); ?>" alt="error">Bank MIS</a>
                </li>
                <?php endif; ?>



                <?php if(auth()->user()->hasPermission('settlement','view')): ?>
                <li class="list-item <?php echo e((Request::path() == 'settlement')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'settlement')?'active-li':''); ?>" href="<?php echo e(url('settlement')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'settlement')?'assets/images/settlement-active.svg':'assets/images/settlement.svg')); ?>" alt="error">Settlements
                    </a>
                </li>
                <?php endif; ?>
                <?php if(auth()->user()->hasPermission('dsa-code','view')): ?>
                <li class="list-item <?php echo e((Request::path() == 'dsa-code')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'dsa-code')?'active-li':''); ?>" href="<?php echo e(url('dsa-code')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'dsa-code')?'assets/images/dsa-code-active.svg':'assets/images/dsa-code.svg')); ?>" alt="error">Bank Code</a>
                </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('bank-target','view')): ?>
                <li class="list-item <?php echo e((Request::path() == 'bank-target')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'bank-target')?'active-li':''); ?>" href="<?php echo e(url('bank-target')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'bank-target')?'assets/images/target-active.svg':'assets/images/target.svg')); ?>" alt="error">Bank Target</a>
                </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('sheet-matching','view')): ?>
                <li class="list-item <?php echo e((Request::path() == 'sheet-matching')?'active-li':''); ?>">
                    <a class="nav-links <?php echo e((Request::path() == 'sheet-matching')?'active-li':''); ?>" href="<?php echo e(url('sheet-matching')); ?>">
                        <img class="dashboard-icons" src="<?php echo e(asset((Request::path() == 'sheet-matching')?'assets/images/sheet-active.svg':'assets/images/sheet.svg')); ?>" alt="error">Sheet Data
                    </a>
                </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('bank','view') ): ?>
                <li class="nav-item dropdown list-item <?php echo e((Request::path() == 'bank' ||Request::path() == 'bank/view/product')?'active':''); ?>">
                    <a class="nav-link dropdown-toggle nav-links" role="button" data-bs-toggle="dropdown">
                        <img class="dashboard-icons" src="<?php echo e(asset('assets/images/bank.svg')); ?>" alt="error">Bank
                        <span class="custom-dropdown-arrow">
                            <img class="dropdown-icon" src="<?php echo e(asset((Request::path() == 'bank' ||Request::path() == 'bank/view/product')?'assets/images/arrow-dropdown.svg':'assets/images/close-dropdown-sidebar-icon.svg')); ?>" alt="arrow">
                        </span>
                    </a>
                    <ul class="dropdown-menu sidebar-menu <?php echo e((Request::path() == 'bank' ||Request::path() == 'bank/view/product')?'show':''); ?>">

                        <li class="dropdown-list-li <?php echo e((Request::path() == 'bank')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'bank')?'active-li':''); ?>" href="<?php echo e(url('bank')); ?>">All Bank</a>
                        </li>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'product')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'product')?'active-li':''); ?>" href="<?php echo e(url('product')); ?>">All Product</a>
                        </li>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'bank/view/product')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'bank/view/product')?'active-li':''); ?>" href="<?php echo e(url('bank/view/product')); ?>">Bank Product</a>
                        </li>

                    </ul>
                </li>
                <?php endif; ?>
                <?php if(auth()->user()->hasPermission('channel','view') ||auth()->user()->hasPermission('sales-person','view') ): ?>

                <li class="nav-item dropdown list-item <?php echo e((Request::path() == 'channel' ||Request::path() == 'sales-person')?'active':''); ?>">
                    <a class="nav-link dropdown-toggle nav-links" role="button" data-bs-toggle="dropdown">
                        <img class="dashboard-icons" src="<?php echo e(asset('assets/images/users.svg')); ?>" alt="error">Users
                        <span class="custom-dropdown-arrow">
                            <img class="dropdown-icon" src="<?php echo e(asset((Request::path() == 'channel' ||Request::path() == 'sales-person')?'assets/images/arrow-dropdown.svg':'assets/images/close-dropdown-sidebar-icon.svg')); ?>" alt="arrow">
                        </span>
                    </a>
                    <ul class="dropdown-menu sidebar-menu <?php echo e((Request::path() == 'channel' ||Request::path() == 'sales-person')?'show':''); ?>">
                        <?php if(auth()->user()->hasPermission('channel','view') ): ?>

                        <li class="dropdown-list-li <?php echo e((Request::path() == 'channel')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'channel')?'active-li':''); ?>" href="<?php echo e(url('channel')); ?>">Channel Partner</a>
                        </li>
                        <?php endif; ?>

                        <?php if(auth()->user()->hasPermission('sales-person','view') ): ?>

                        <li class="dropdown-list-li <?php echo e((Request::path() == 'sales-person')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'sales-person')?'active-li':''); ?>" href="<?php echo e(url('sales-person')); ?>">Sales Person</a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>
                <?php endif; ?>

                <?php if(auth()->user()->hasPermission('staff','view')): ?>
                <li class="nav-item dropdown list-item <?php echo e((Request::path() == 'staff' ||Request::path() == 'staff/view/role'||Request::path() =='staff/view/permissions')?'active':''); ?>">
                    <a class="nav-link dropdown-toggle nav-links" role="button" data-bs-toggle="dropdown">
                        <img class="dashboard-icons" src="<?php echo e(asset('assets/images/staff.svg')); ?>" alt="error">Staff
                        <span class="custom-dropdown-arrow">
                            <img class="dropdown-icon" src="<?php echo e(asset((Request::path() == 'staff' ||Request::path() == 'staff/view/role'||Request::path() =='permissions')?'assets/images/arrow-dropdown.svg':'assets/images/close-dropdown-sidebar-icon.svg')); ?>" alt="arrow">
                        </span>
                    </a>
                    <ul class="dropdown-menu sidebar-menu <?php echo e((Request::path() == 'staff' ||Request::path() == 'staff/view/role'||Request::path() =='staff/view/permissions')?'show':''); ?>">
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'staff')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'staff')?'active-li':''); ?>" href="<?php echo e(url('staff')); ?>">Manage Staff</a>
                        </li>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'staff/view/role')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'staff/view/role')?'active-li':''); ?>" href="<?php echo e(url('staff/view/role')); ?>">Roles</a>
                        </li>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'staff/view/permissions')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'staff/view/permissions')?'active-li':''); ?>" href="<?php echo e(url('staff/view/permissions')); ?>">Permissions</a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if(auth()->user()->hasPermission('services','view') ||auth()->user()->hasPermission('bank-payout','view') ): ?>
                <li class="nav-item dropdown list-item <?php echo e((Request::path() == 'services' || Request::path() == 'bank-payout')?'active':''); ?>">
                    <a class="nav-link dropdown-toggle nav-links" role="button" data-bs-toggle="dropdown">
                        <img class="dashboard-icons" src="<?php echo e(asset('assets/images/setting.svg')); ?>" alt="error">Setting
                        <span class="custom-dropdown-arrow">
                            <img class="dropdown-icon" src="<?php echo e(asset((Request::path() == 'services' || Request::path() == 'bank-payout' || Request::path() == 'remark-status')?'assets/images/arrow-dropdown.svg':'assets/images/close-dropdown-sidebar-icon.svg')); ?>" alt="arrow">
                        </span>
                    </a>
                    <ul class="dropdown-menu sidebar-menu <?php echo e((Request::path() == 'services' || Request::path() == 'bank-payout')?'show':''); ?>">
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'services')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'services')?'active-li':''); ?>" href="<?php echo e(url('services')); ?>">Services</a>
                        </li>
                        <?php if(auth()->user()->roles[0]->id ==1): ?>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'bank-payout')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'bank-payout')?'active-li':''); ?>" href="<?php echo e(url('bank-payout')); ?>">Bank Payout</a>
                        </li>
                        <?php endif; ?>
                        <?php if(auth()->user()->roles[0]->id ==1): ?>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'remark-status')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'remark-status')?'active-li':''); ?>" href="<?php echo e(url('remark-status')); ?>">Remark Status</a>
                        </li>
                        <?php endif; ?>
                        <?php if(auth()->user()->roles[0]->id ==1): ?>
                        <li class="dropdown-list-li <?php echo e((Request::path() == 'master-code')?'active-li':''); ?>">
                            <a class="dropdown-item nav-links <?php echo e((Request::path() == 'master-code')?'active-li':''); ?>" href="<?php echo e(url('master-code')); ?>">Master Code</a>
                        </li>
                        <?php endif; ?>

                    </ul>
                </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
    <!-- <div>
        <button class="log-out-btn" onclick="window.location.href=`<?php echo e(url('logout')); ?>`">
            <img class="dashboard-icons" src="<?php echo e(asset('assets/images/logout-icon.svg')); ?>">Log out
        </button>
    </div> -->
</div><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Layout/sidebar.blade.php ENDPATH**/ ?>