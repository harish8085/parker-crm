<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/settlement.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/add.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/add-service-1.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/import.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="breadcrumb-container" style="margin-bottom: 24px;">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-white px-0 py-2" style="margin-bottom:0;">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/bank')); ?>">Banks</a></li>
            <li class="breadcrumb-item active" aria-current="page">Edit Bank</li>
        </ol>
    </nav>
</div>
<form action="<?php echo e(url('/bank/update/'.$bank->id)); ?>" method="POST">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <div class="bank-card">
        <div class="row m-0 card-top-border">
            <div class="col-sm-9">
                Basic Details
            </div>
        </div>
        <div class="card-form">
            <div class="bank-detail-inputs">
                <label class="bank-input-label">Bank Name<span class="required">*</span></label>
                <input class="bank-detail-input form-control" type="text" name="name" id="name" placeholder="Enter Bank Name" value="<?php echo e($bank->name); ?>" required>
            </div>
            <div class="bank-detail-inputs">
                <label class="bank-input-label">Short Name<span class="required">*</span></label>
                <input class="bank-detail-input form-control" type="text" name="short_name" id="short_name" placeholder="Enter Short Name" value="<?php echo e($bank->short_name); ?>" required>
            </div>
        </div>
    </div>
    <br>
    <center>
        <div class="col-sm-12">
            <button type="submit" class="btn btn-success mt-2">Save</button>
        </div>
    </center>

</form>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#uploadBtn').click(function() {
            $('#xlsx_file').click();
        });

        $('#xlsx_file').change(function() {
            var fileInput = $(this)[0].files[0];
            var formData = new FormData();
            formData.append('file', fileInput);

            $.ajax({
                url: '/getFileData',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    var select = $('.row_select');
                    select.empty().append($('<option>', {
                        value: '',
                        text: 'Select',
                        disabled: true,
                        selected: true
                    }));

                    $.each(response, function(key, value) {
                        select.append($('<option>', {
                            value: value,
                            text: value
                        }));
                    });
                },
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        });

        $('#bank_id,#group').change(function() {
            if ($('#bank_id').val() && $('#group').val()) {
                performAjaxRequest('/getProduct', 'POST', {
                    bank_id: $('#bank_id').val(),
                    group: $('#group').val(),
                }, function(response) {
                    var select = $('#product_id')
                    select.empty().append($('<option>', {
                        value: '',
                        text: 'Select Product',
                        disabled: true,
                        selected: true
                    }));

                    $.each(response, function(key, value) {
                        select.append($('<option>', {
                            value: value.id,
                            text: value.name
                        }));
                    });
                });
            }
        });

        $('#submitBtn').click(function(event) {
            // Prevent default form submission
            event.preventDefault();

            // Perform form validation
            var isValid = true;


            if (!$('#app_id').val()) {
                $('#app_id').removeClass('is-valid').addClass('is-invalid');
                $('#app_id').focus();
                isValid = false;
                return false;
            } else {
                $('#app_id').addClass('is-valid').removeClass('is-invalid');
            }


            if (!$('#disbursement_date').val()) {
                $('#disbursement_date').removeClass('is-valid').addClass('is-invalid');
                $('#disbursement_date').focus();
                isValid = false;
                return false;

            } else {
                $('#disbursement_date').addClass('is-valid').removeClass('is-invalid');
            }

            if (!$('#customer_name').val()) {
                $('#customer_name').removeClass('is-valid').addClass('is-invalid');
                $('#customer_name').focus();
                isValid = false;
                return false;
            } else {
                $('#customer_name').addClass('is-valid').removeClass('is-invalid');
            }

            if (!$('#case_state').val()) {
                $('#case_state').removeClass('is-valid').addClass('is-invalid');
                $('#case_state').focus();
                isValid = false;
                return false;

            } else {
                $('#case_state').addClass('is-valid').removeClass('is-invalid');
            }

            if (!$('#case_location').val()) {
                $('#case_location').removeClass('is-valid').addClass('is-invalid');
                $('#case_location').focus();
                isValid = false;
                return false;

            } else {
                $('#case_location').addClass('is-valid').removeClass('is-invalid');
            }


            if (!$('#bank_id').val()) {
                $('#bank_id').removeClass('is-valid').addClass('is-invalid');
                $('#bank_id').focus();
                $('.invalid-feedback').show()
                isValid = false;
                return false;
            } else {
                $('#bank_id').addClass('is-valid').removeClass('is-invalid');
                $('.invalid-feedback').hide()

            }


            if (!$('#product_id').val()) {
                $('#product_id').removeClass('is-valid').addClass('is-invalid');
                $('#product_id').focus();
                isValid = false;
                return false;

            } else {
                $('#product_id').addClass('is-valid').removeClass('is-invalid');
            }

            if (!$('#group').val()) {
                $('#group').removeClass('is-valid').addClass('is-invalid');
                $('#group').focus();
                isValid = false;
                return false;

            } else {
                $('#group').addClass('is-valid').removeClass('is-invalid');
            }

            if ($('#group').val() == 'Secured') {
                if (!$('#fresh_bt').val()) {
                    $('#fresh_bt').removeClass('is-valid').addClass('is-invalid');
                    $('#fresh_bt').focus();
                    isValid = false;
                    return false;

                } else {
                    $('#fresh_bt').addClass('is-valid').removeClass('is-invalid');
                }


                if (!$('#any_subvention').val()) {
                    $('#any_subvention').removeClass('is-valid').addClass('is-invalid');
                    $('#any_subvention').focus();
                    isValid = false;
                    return false;

                } else {
                    $('#any_subvention').addClass('is-valid').removeClass('is-invalid');
                }
            } else {
                if (!$('#otc_pdd').val()) {
                    $('#otc_pdd').removeClass('is-valid').addClass('is-invalid');
                    $('#otc_pdd').focus();
                    isValid = false;
                    return false;

                } else {
                    $('#otc_pdd').addClass('is-valid').removeClass('is-invalid');
                }



                if (!$('#pf_taken').val()) {
                    $('#pf_taken').removeClass('is-valid').addClass('is-invalid');
                    $('#pf_taken').focus();
                    isValid = false;
                    return false;

                } else {
                    $('#pf_taken').addClass('is-valid').removeClass('is-invalid');
                }
            }



            if (!$('#disburse_amount').val()) {
                $('#disburse_amount').removeClass('is-valid').addClass('is-invalid');
                $('#disburse_amount').focus();
                isValid = false;
                return false;

            } else {
                $('#disburse_amount').addClass('is-valid').removeClass('is-invalid');
            }
            if (!$('#banker_name').val()) {
                $('#banker_name').removeClass('is-valid').addClass('is-invalid');
                $('#banker_name').focus();
                isValid = false;
                return false;

            } else {
                $('#banker_name').addClass('is-valid').removeClass('is-invalid');
            }

            if (!$('#banker_number').val()) {
                $('#banker_number').removeClass('is-valid').addClass('is-invalid');
                $('#banker_number').focus();
                isValid = false;
                return false;
            } else {
                $('#banker_number').addClass('is-valid').removeClass('is-invalid');
            }


            if (!$('#banker_email').val()) {
                $('#banker_email').removeClass('is-valid').addClass('is-invalid');
                $('#banker_email').focus();
                isValid = false;
                return false;
            } else {
                $('#banker_email').addClass('is-valid').removeClass('is-invalid');
            }

            // If form is valid, submit the form
            if (isValid) {
                $('.needs-validation').submit();
            }
        });

        function performAjaxRequest(url, type, data, successCallback) {
            $.ajax({
                url: url,
                type: type,
                data: data,
                success: successCallback,
                error: function(xhr) {
                    console.log(xhr.responseText);
                }
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Bank/edit.blade.php ENDPATH**/ ?>