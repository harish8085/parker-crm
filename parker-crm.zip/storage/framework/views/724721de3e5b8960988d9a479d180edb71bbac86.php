<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/permissions.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-table.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div>
    <h2 class="permission-heading">PERMISSIONS</h2>
    <p class="permission-pg">Select Role to Get & Set Permissions</p>
    <div>
        <div class="dropdown permission">
            <select class="form-select" required name="role" id="role">
                <option value="" selected disabled>Select Role</option>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>



    <div class="table-responsive">
        <table class="table ">
            <thead>
                <tr>
                    <th class="table-header">Module </th>
                    <th class="table-header">Create </th>
                    <th class="table-header">Read</th>
                    <th class="table-header">Update</th>
                    <th class="table-header">Delete</th>
                </tr>
            </thead>
            <tbody id="tableBody">



            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#role').change(function() {
            $.get(`<?php echo e(('/staff/view/getPermission/')); ?>` + $(this).val(), function(response) {
                $('#tableBody').html(response)
            });
        });
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#tableBody').on('change', '.form-check-input', function() {
            var permissionId = $(this).closest('tr').data('permission-id');
            var attribute = $(this).attr('name');
            var value = $(this).is(':checked') ? 'active' : 'in-active';

            $.ajax({
                url: `<?php echo e(('/staff/create/updatePermission')); ?>`,
                type: 'POST',
                data: {
                    permission_id: permissionId,
                    [attribute]: value
                },
                success: function(response) {
                    if (response.success) {
                        // Optionally update UI to indicate successful update
                    }
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    // Handle error
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Staff/permission/index.blade.php ENDPATH**/ ?>