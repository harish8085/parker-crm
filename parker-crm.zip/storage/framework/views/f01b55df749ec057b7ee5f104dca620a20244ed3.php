  <table class="table table-hover  data-table">
      <thead>
          <tr>
              <th class="table-header">S.NO</th>
              <th class="table-header">Bank Name</th>
              <th class="table-header">Product Name</th>
              <th class="table-header">Group</th>
              <th class="table-header">DSA Code</th>
              <th class="table-header">Actions</th>
          </tr>
      </thead>
      <tbody>

      </tbody>
  </table><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/DSA/Table/dsa_table.blade.php ENDPATH**/ ?>