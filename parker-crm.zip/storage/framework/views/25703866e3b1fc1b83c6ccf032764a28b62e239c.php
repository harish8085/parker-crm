<table class="table table-hover text-nowrap data-table">
            <thead>
                <tr>
                    <th class="table-header">S.No</th>
                    <th class="table-header">Channel ID</th>
                    <th class="table-header">Channel name</th>
                    <th class="table-header">Email</th>
                    <th class="table-header">Phone</th>
                    <th class="table-header">Status</th>
                    <th class="table-header">Actions</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Users/channel-partner/Table/table.blade.php ENDPATH**/ ?>