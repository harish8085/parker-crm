
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/application.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/custom-table.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/settlement.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/paginate.css')); ?>">
<style>
    .mc-grid{gap:22px}
    .qr-side{background:#f3f6ff;border:1px solid #e6ecff;border-radius:10px;padding:20px}
    .qr-title{font-size:14px;font-weight:600;color:#6b7280;text-align:center;margin-bottom:10px}
    .qr-card{background:#fff;border-radius:10px;padding:10px;box-shadow:0 6px 18px rgba(0,0,0,.08)}
    .qr-actions .btn{min-width:130px}
    @media(min-width:992px){.left-pane{padding-right:18px}}
    .success-pill{display:inline-block;background:#22c55e;color:#fff;border-radius:6px;padding:6px 12px;font-size:12px}
    .field-hint{font-size:12px;color:#8a94a6}
    /* mock-style panels */
    .panel-box{background:#fff;border:2px solid #12182610;border-radius:8px;box-shadow:0 4px 14px rgba(18,24,38,0.06)}
    .panel-pad{padding:24px}
    .inner-field{max-width:720px}
    .inner-field .form-control{height:44px}
    .update-wrap{max-width:260px}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div class="card">
    <div class="application-header">
        <h3 class="application-heading">Master Code</h3>
    </div>

    <div class="bank-card p-4">
        <?php if(session('success')): ?>
        <div class="alert alert-success mb-3"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('master-code.update')); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php if(!empty($masterCodes->code)): ?>
            <div class="col-lg-3 mb-3">
                    <div class="panel-box panel-pad h-100 d-flex flex-column align-items-left justify-content-center">
                       
                        <div class="qr-card mb-2">
                            <img id="qr-img" src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=<?php echo e(urlencode($masterCodes->code ?? '')); ?>" alt="QR Code" width="220" height="220">
                        </div>
                        <div class="qr-actions d-flex gap-2 mt-1">
                            <a id="download-qr" class="btn btn-sm btn-outline-primary" href="<?php echo e(route('master-code.download')); ?>">Download PNG</a>
                            <a id="email-share" class="btn btn-sm btn-outline-secondary" href="mailto:?subject=<?php echo e(urlencode('Master Code QR')); ?>&body=<?php echo e(urlencode(('Here is the master code: '.($masterCodes->code ?? ''))."%0D%0ADownload the QR PNG here: ".route('master-code.download'))); ?>">Email</a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="col-lg-6 mb-3">
                    <div class="panel-box panel-pad">
                        <div class="bank-detail-inputs inner-field">
                            <label class="bank-input-label">Master Code</label>
                            <input id="master-code-input" type="text" class="form-control" name="code" placeholder="Enter new master code..." value="<?php echo e(old('code', $masterCodes->code ?? '')); ?>" required>
                            <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="update-wrap mt-3">
                            <button type="submit" class="application-header-btn w-100">
                                <img class="application-header-icon" src="<?php echo e(asset('assets/images/add-table-icon.svg')); ?>">Update Code
                            </button>
                        </div>
                    </div>
                </div>

                
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/master-code/index.blade.php ENDPATH**/ ?>