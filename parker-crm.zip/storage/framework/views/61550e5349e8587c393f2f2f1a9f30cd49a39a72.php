  <table class="table table-hover text-nowrap data-table">
      <thead>
          <tr>
              <th class="table-header">S.NO</th>
              <th class="table-header">Service Name</th>
              <th class="table-header">Actions</th>
          </tr>
      </thead>
      <tbody>

      </tbody>
  </table><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Setting/Service/Table/service_table.blade.php ENDPATH**/ ?>