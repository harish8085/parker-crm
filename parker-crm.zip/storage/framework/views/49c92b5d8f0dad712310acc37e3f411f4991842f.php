  <table class="table table-hover data-table">
      <thead>
          <tr>
              <th class="table-header">Product ID</th>
              <th class="table-header">Product Name</th>
              <th class="table-header">Group</th>
              <th class="table-header">Actions</th>
          </tr>
      </thead>
      <tbody>

      </tbody>
  </table><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Product/Table/product_table.blade.php ENDPATH**/ ?>