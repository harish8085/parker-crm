<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/add-service.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<div>
    <div class="bank-card">
        <div class="card-top-border">Add Service Details</div>
        <div class="card-form">
            <div class="bank-detail-inputs">
                <label class="bank-input-label">Service Name</label>
                <input class="bank-detail-input" id="service_name" type="text" placeholder="Enter service name" />
            </div>

        </div>
    </div>
    <div id="data">
        <?php echo $__env->make('Frontend.Setting.Service.component.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp8.2\htdocs\parker-crm\resources\views/Frontend/Setting/Service/create.blade.php ENDPATH**/ ?>