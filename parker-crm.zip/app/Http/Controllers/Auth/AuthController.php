<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Service;
use App\Models\MasterCode;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class AuthController extends Controller
{
    public function index()
    {
        $user_id =  Auth::id();
        if (Auth::user()) {
            return redirect('/dashboard');
        } else {
            return view('Auth.login');
        }
    }

    public function Login(Request $request)
    {

        if (!empty($request)) {
            $email = $request->email;
            $password = $request->password;


            if (!empty($email) && !empty($password)) {

                // Determine the subdomain and user type
                $subdomain = explode('.', $request->getHost())[0];
                switch ($subdomain) {
                    case 'admin':
                        $type = ['admin', 'staff']; // Search for both admin and staff types
                        break;
                    case 'parker':
                        $type = ['admin', 'staff','channel','sales'];
                        break;
                    case 'partner':
                        $type = ['channel'];
                        break;
                    case 'sales-team':
                        $type = ['sales'];
                        break;
                    default:
                        $type = ['admin', 'staff','channel','sales'];
                        break;
                }
                $userdata = array(
                    'email' => $email,
                    'password' => $password,
                );

                if (Auth::attempt($userdata)) {
                    $user = Auth::user();

                    if (in_array($user->user_type, $type)) {
                        if ($request->has('remember') == null) {
                            setcookie('email', $email, 100);
                            setcookie('password', $password, 100);
                        } else {

                            setcookie('email', $email, time() + 606024100);
                            setcookie('password', $password, time() + 606024100);
                        }
                        session('Login', true);
                        flash()
                            ->success('Logged In successfully.')
                            ->flash();
                        return redirect('/application');
                    } else {
                        Session::flush();
                        Auth::logout();
                        flash()
                            ->error('Account does not exists.')
                            ->flash();
                        return redirect('/');
                    }
                } else {
                    return redirect()->back()->with('error', "Invalid Credential");
                }
            } else {
                return redirect()->back()->with('error', "Invalid Request");
            }
        } else {
            return redirect()->back()->with('error', "Invalid Request");
        }
        return view("Auth.Login");
    }


    public function Logout()
    {
        Session::flush();
        flash()
            ->success('Logged Out successfully.')
            ->flash();
        return redirect('/');
    }

    public function signup()
    {
        $user_id = Auth::id();
        if (Auth::user()) {
            return redirect('/dashboard');
        } else {
            // Get states and services for the signup form
            $states = [
                ['state_code' => 'AP', 'state' => 'Andhra Pradesh'],
                ['state_code' => 'AR', 'state' => 'Arunachal Pradesh'],
                ['state_code' => 'AS', 'state' => 'Assam'],
                ['state_code' => 'BR', 'state' => 'Bihar'],
                ['state_code' => 'CT', 'state' => 'Chhattisgarh'],
                ['state_code' => 'GA', 'state' => 'Goa'],
                ['state_code' => 'GJ', 'state' => 'Gujarat'],
                ['state_code' => 'HR', 'state' => 'Haryana'],
                ['state_code' => 'HP', 'state' => 'Himachal Pradesh'],
                ['state_code' => 'JK', 'state' => 'Jammu and Kashmir'],
                ['state_code' => 'JH', 'state' => 'Jharkhand'],
                ['state_code' => 'KA', 'state' => 'Karnataka'],
                ['state_code' => 'KL', 'state' => 'Kerala'],
                ['state_code' => 'MP', 'state' => 'Madhya Pradesh'],
                ['state_code' => 'MH', 'state' => 'Maharashtra'],
                ['state_code' => 'MN', 'state' => 'Manipur'],
                ['state_code' => 'ML', 'state' => 'Meghalaya'],
                ['state_code' => 'MZ', 'state' => 'Mizoram'],
                ['state_code' => 'NL', 'state' => 'Nagaland'],
                ['state_code' => 'OR', 'state' => 'Odisha'],
                ['state_code' => 'PB', 'state' => 'Punjab'],
                ['state_code' => 'RJ', 'state' => 'Rajasthan'],
                ['state_code' => 'SK', 'state' => 'Sikkim'],
                ['state_code' => 'TN', 'state' => 'Tamil Nadu'],
                ['state_code' => 'TG', 'state' => 'Telangana'],
                ['state_code' => 'TR', 'state' => 'Tripura'],
                ['state_code' => 'UP', 'state' => 'Uttar Pradesh'],
                ['state_code' => 'UT', 'state' => 'Uttarakhand'],
                ['state_code' => 'WB', 'state' => 'West Bengal'],
                ['state_code' => 'AN', 'state' => 'Andaman and Nicobar Islands'],
                ['state_code' => 'CH', 'state' => 'Chandigarh'],
                ['state_code' => 'DN', 'state' => 'Dadra and Nagar Haveli'],
                ['state_code' => 'DD', 'state' => 'Daman and Diu'],
                ['state_code' => 'DL', 'state' => 'Delhi'],
                ['state_code' => 'LD', 'state' => 'Lakshadweep'],
                ['state_code' => 'PY', 'state' => 'Puducherry']
            ];
            
            $services = Service::all();
            
            return view('Auth.signup', compact('states', 'services'));
        }
    }

    public function register(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|string|min:10|max:10|unique:users',
            'password' => 'required|string|min:8|confirmed',
            'pan_number' => 'required|string|regex:/^[A-Z]{5}[0-9]{4}[A-Z]$/',
            'aadhar_number' => 'required|string|regex:/^\d{12}$/',
            'verification_code' => 'required|string',
            'address_1' => 'required|string|max:255',
            'address_2' => 'required|string|max:255',
            'landmark' => 'required|string|max:255',
            'state' => 'required|string',
            'district' => 'required|string',
            'pincode' => 'required|string|regex:/^\d{6}$/',
            'bank_name' => 'required|string|max:255',
            'branch_name' => 'required|string|max:255',
            'holder_name' => 'required|string|max:255',
            'account_number' => 'required|string',
            'confirm_account_number' => 'required|string|same:account_number',
            'ifsc_code' => 'required|string|regex:/^[A-Z]{4}[0][A-Z0-9]{6}$/',
            'service_type' => 'required|exists:services,id',
        ]);

        // Validate verification code against master code
        $masterCode = MasterCode::first();
        if (!$masterCode || $masterCode->code !== $request->verification_code) {
            return redirect()->back()
                ->withErrors(['verification_code' => 'Invalid verification code. Please contact your administrator.'])
                ->withInput();
        }

        try {
            $user = User::create([
                'first_name' => $request->first_name,
                'email' => $request->email,
                'phone' => $request->phone,
                'password' => Hash::make($request->password),
                'pan_number' => $request->pan_number,
                'aadhar_number' => $request->aadhar_number,
                'address_1' => $request->address_1,
                'address_2' => $request->address_2,
                'landmark' => $request->landmark,
                'state' => $request->state,
                'district' => $request->district,
                'pincode' => $request->pincode,
                'bank_name' => $request->bank_name,
                'branch_name' => $request->branch_name,
                'holder_name' => $request->holder_name,
                'account_number' => $request->account_number,
                'ifsc_code' => $request->ifsc_code,
                'service_type' => $request->service_type,
                'user_type' => 'channel',
                'status' => 1,
            ]);

            flash()
                ->success('Registration successful! Please login with your credentials.')
                ->flash();
            
            return redirect('/');
        } catch (\Exception $e) {
            flash()
                ->error('Registration failed. Please try again.')
                ->flash();
            
            return redirect()->back()->withInput();
        }
    }
}
