<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    // Other model properties and methods...

    protected $fillable = [
        'name',
        'create',
        'update',
        'view',
        'delete',
    ];


    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

}
