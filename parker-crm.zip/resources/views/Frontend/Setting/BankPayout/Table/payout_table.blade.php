  <table class="table table-hover data-table">
      <thead>
          <tr>
              <th class="table-header">S.NO</th>
              <th class="table-header">Bank Name</th>
              <th class="table-header">Product Name</th>
              <th class="table-header">Payout Rate</th>
              <th class="table-header">Actions</th>
          </tr>
      </thead>
      <tbody>

      </tbody>
  </table>